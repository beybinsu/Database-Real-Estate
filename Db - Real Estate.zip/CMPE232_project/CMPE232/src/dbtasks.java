import java.sql.*;
import java.io.*;
import java.util.*;


public class dbtasks {

	private static Connection connect = null;
	private static Statement statement  = null;
	private static ResultSet resultSet = null;
	
	final private static String host = "jdbc:postgresql://10.98.98.61:5432/group56";
	final private static String user = "group56";
	final private static String password = "=%4Dnj9YPtNRKHJg";
	
	public static void main(String[] args) {
		
		System.out.println("Welcome to the Real Estate Office Management System!");	
		Scanner scan = new Scanner(System.in);
		
		try
		{		
			connect = DriverManager.getConnection(host, user, password);
			statement = connect.createStatement();	
			
			int control = 1;
			
			while(control != 0)
			{
				
				System.out.println("->To exit the program enter 0.");
				System.out.println("->To get all the active offices enter 1.");
				System.out.println("->To get all the houses enter 2.");
				System.out.println("->To get all the employees enter 3.");
				System.out.println("->To get all the customers enter 4.");
				System.out.println("->To get all the property owners enter 5.");
				System.out.println("->To insert a customer to system enter 6.");
				System.out.println("->To update a phone number of property owner enter 7.");
				System.out.println("->To delete a customer from system, please enter 8.");
				System.out.println("Please enter a number:");
				control = scan.nextInt();
			
				if(control == 1)
				{	
					 
					resultSet = statement.executeQuery("select *from realestateoffice FULL OUTER JOIN EstateLocation on realestateoffice.estateid = estatelocation.estateid "   );
					
					

					
					while (resultSet.next()) 
					{
						System.out.println("");
						System.out.println("-------------------------------------------------------------------");
						System.out.println("Estate location: " + resultSet.getString("EstateLocation"));
						System.out.println("Estate office phone number: " + resultSet.getString("phoneNum"));
						System.out.println("Estate ID: " + resultSet.getString("estateID"));
						System.out.println("Estate Budget: " + resultSet.getString("budget"));
						System.out.println("-------------------------------------------------------------------");	
						
					}
					System.out.println("");
					
				}
				else if(control == 2)
				{
					System.out.println("Please enter a district:");
					String district = scan.next();
					resultSet = statement.executeQuery("SELECT  property.type_of , property.numberofrooms , property.propertylocation ,property.employeeid ,property.ownerid ,employee.employeeid ,employee.firstname  as ename,employee.lastname as lename,employee.phonenum as ephoneNumber,PropertyOwner.firstname ,PropertyOwner.lastname ,PropertyOwner.phonenum FROM Property JOIN PropertyOwner on Property.ownerID=PropertyOwner.ownerID join employee on employee.employeeid = property.employeeid WHERE propertyLocation LIKE" + "'%" +district + "%'");

					while (resultSet.next()) 
					{
						System.out.println("");
						System.out.println("-------------------------------------------------------------------");
						System.out.println("Adress of the House: " + resultSet.getString("propertyLocation") );
						System.out.println("Room number of the house: " +resultSet.getString("numberOfRooms"));
						System.out.println("Type of the House: " + resultSet.getString("type_of"));
						System.out.println("Full Name of the owner: " + resultSet.getString("lastname") + " " + resultSet.getString("firstname"));
						System.out.println("Phone Number of the owner: " + resultSet.getString("phoneNum"));
						System.out.println("Full name of responsible employee: " + resultSet.getString("ename") + " " + resultSet.getString("lename") );
						System.out.println("Phone number of responsible employee: " + resultSet.getString("ephonenumber"));
						System.out.println("-------------------------------------------------------------------");
			
					}
					System.out.println("");
				}
				else if(control ==3)
				{
					
					resultSet = statement.executeQuery("select employee.*,realestateoffice.phonenum as EOphonenumber,estatelocation.*from employee join realestateoffice on employee.estateid = realestateoffice.estateid  join EstateLocation on EstateLocation.estateid = employee.estateid "  );

					
					while (resultSet.next()) 
					{
						System.out.println("");
						System.out.println("-------------------------------------------------------------------");
						System.out.println("Full Name of the employee: " + resultSet.getString("firstname") + " " + resultSet.getString("lastname"));
						System.out.println("Gender of the employee: " + resultSet.getString("gender"));
						System.out.println("Birth date of the employee: " + resultSet.getString("birthDate"));
						System.out.println("Phone number of the employee: " + resultSet.getString("phoneNum"));
						System.out.println("Estate office location that s/he is working: " + resultSet.getString("EstateLocation"));
						System.out.println("Estate office phone number of office that s/he is working: " + resultSet.getString("EOphonenumber"));
						System.out.println("-------------------------------------------------------------------");
						
						
					}
					System.out.println("");
					
				}
				else if(control ==4)
				{
					resultSet = statement.executeQuery("SELECT * FROM Customer"  );

					
					while (resultSet.next()) 
					{
						System.out.println("");
						System.out.println("-------------------------------------------------------------------");
						System.out.println("Customers name/surname:" + resultSet.getString("firstname") + " " +resultSet.getString("lastname"));
						System.out.println("Customers phone number:" + resultSet.getString("phoneNum"));
						System.out.println("Customers number of children:" + resultSet.getString("numOfChildren"));
						System.out.println("Customers budget:" + resultSet.getString("price"));
						System.out.println("Customer ID: " +resultSet.getString("CustomerID"));
						System.out.println("-------------------------------------------------------------------");
												
					}
					System.out.println("");

					
				}
				else if(control == 5)
				{
					
					resultSet = statement.executeQuery("SELECT * FROM PropertyOwner"  );

					
					while (resultSet.next()) 
					{
						System.out.println("");
						System.out.println("-------------------------------------------------------------------");
						System.out.println("Owner name/surname:" + resultSet.getString("firstname") + " " +resultSet.getString("lastname"));
						System.out.println("Owner phone number:" + resultSet.getString("phoneNum"));
						System.out.println("Owner ID:" + resultSet.getString("ownerID"));
						System.out.println("-------------------------------------------------------------------");
						
					}
					System.out.println("");
				}
				else if(control == 6)
				{
					System.out.println("Enter new customers ID:");
					int ID = scan.nextInt();
					System.out.println("Enter new customers name:");
					String name = scan.next();
					System.out.println("Enter new customers surname:");
					String surname = scan.next();
					System.out.println("Enter new customers birth date:(Please enter as year-month-day):");
					String birthDate = scan.next();
					System.out.println("Enter the gender of customer:");
					String gender  = scan.next();
					System.out.println("Enter the budget of the customer:");
					int budget = scan.nextInt();
					System.out.println("Enter the phone number of the customer:");
					String phoneNumber = scan.next();
					System.out.println("Enter the number of childs of the customer:");
					int childs = scan.nextInt();
					
					resultSet = statement.executeQuery("SELECT * FROM Customer"  );
					
					System.out.println("");

					System.out.println("---Old List of the Customers---");
				
					
					while (resultSet.next()) 
					{
						
						
						System.out.println("");
						System.out.println("-------------------------------------------------------------------");
						System.out.println("Customers name/surname:" + resultSet.getString("firstname") + " " +resultSet.getString("lastname"));
						System.out.println("Customers phone number:" + resultSet.getString("phoneNum"));
						System.out.println("Customers number of children:" + resultSet.getString("numOfChildren"));
						System.out.println("Customers budget:" + resultSet.getString("price"));
						System.out.println("Customer ID: " +resultSet.getString("CustomerID"));
						System.out.println("-------------------------------------------------------------------");
												
					}
					System.out.println("");
					
					int x = statement.executeUpdate("insert into Customer values(" + ID + ",'" + name + "','" + surname + "','" + birthDate + "','" + gender + "'," + budget + ",'" + phoneNumber + "'," + childs +")"  );
					
					if(x==1)
					{
						System.out.println("Successfully inserted.");
						
						System.out.println("");
						
						System.out.println("---New List of the Customers---");
						
						resultSet = statement.executeQuery("SELECT * FROM Customer"  );
						
						while (resultSet.next()) 
						{
							System.out.println("");
							System.out.println("-------------------------------------------------------------------");
							System.out.println("Customers name/surname:" + resultSet.getString("firstname") + " " +resultSet.getString("lastname"));
							System.out.println("Customers phone number:" + resultSet.getString("phoneNum"));
							System.out.println("Customers number of children:" + resultSet.getString("numOfChildren"));
							System.out.println("Customers budget:" + resultSet.getString("price"));
							System.out.println("Customer ID: " +resultSet.getString("CustomerID"));
							System.out.println("-------------------------------------------------------------------");
													
						}
						System.out.println("");
					}	
					else
					{
						System.out.println("Inserting failed.");
						System.out.println("Please check the informations that you entered about the Customer.");
						System.out.println("");
					}
					
				}
				else if(control == 7)
				{
					System.out.println("Please enter the ID of the property owner:");
					int ID = scan.nextInt();
					System.out.println("Please enter the new phone number:");
					String phoneNumber = scan.next();
					
					resultSet = statement.executeQuery("SELECT * FROM PropertyOwner where ownerID=" + ID  );
					

					while (resultSet.next()) 
					{
						System.out.println("");
						System.out.println("Old informations about owner:");
						System.out.println("");
						System.out.println("-------------------------------------------------------------------");
						System.out.println("Owner name/surname:" + resultSet.getString("firstname") + " " +resultSet.getString("lastname"));
						System.out.println("Owner phone number:" + resultSet.getString("phoneNum"));
						System.out.println("Owner ID:" + resultSet.getString("ownerID"));
						System.out.println("-------------------------------------------------------------------");
						
					}
					System.out.println("");
					
					int x = statement.executeUpdate("Update PropertyOwner Set phoneNum = "+ phoneNumber+"WHERE ownerID = " + ID);
					
					if(x==1)
					{
						System.out.println("");
						System.out.println("New informations about owner:");
						System.out.println("");
						
						resultSet = statement.executeQuery("SELECT * FROM PropertyOwner where ownerID=" + ID  );

						while (resultSet.next()) 
						{
							System.out.println("");
							System.out.println("-------------------------------------------------------------------");
							System.out.println("Owner name/surname:" + resultSet.getString("firstname") + " " +resultSet.getString("lastname"));
							System.out.println("Owner phone number:" + resultSet.getString("phoneNum"));
							System.out.println("Owner ID:" + resultSet.getString("ownerID"));
							System.out.println("-------------------------------------------------------------------");
							
						}
						System.out.println("");
						System.out.println("Update is Successfully");
						System.out.println("");
					}
					else
					{
						System.out.println("Update failed");
						System.out.println("Please check the ID of the owner.");
						System.out.println("");
					}
				}
				else if(control == 8)
				{
					System.out.println("Please enter the ID of the customer.");
					int ID = scan.nextInt();
					
					int x = statement.executeUpdate("Delete from Customer WHERE CustomerID =" + ID);
					
					if(x==1)
					{
						System.out.println("delete is Successfull");
					}
					else
					{
						System.out.println("");
						System.out.println("delete failed");
						System.out.println("Please check the ID of the Customer.");
						System.out.println("");
					}
				}
				else if(control == 0)
				{
					
					System.out.println("Have a nice day!");
					
					
					break;
				}
				else
				{
					
						System.out.println("You entered an invalid number, please enter numbers between 0 - 8");
						System.out.println();
					
					
				}		
			    
			}
			
		}
		
		catch(SQLException e)
		{
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
		

	}
}